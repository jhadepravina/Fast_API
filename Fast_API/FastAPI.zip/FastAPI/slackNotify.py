import requests
import json
from fastapi import FastAPI,Request,HTTPException
import pandas as pd
from tabulate import tabulate
from pydantic import BaseModel,HttpUrl,EmailStr
import traceback2 as traceback
import processTable
from fastapi.encoders import jsonable_encoder
from typing import List,Union,Dict
import Failure_channel
from schema import Inc_List

app=FastAPI()


@app.post('/api/v1/notifyuserslack', tags=['TicketDetails'])
def slack_notify_user(payload:Inc_List):

    json_compatible_item_data = jsonable_encoder(payload)
    #print(json_compatible_item_data)

    ex=processTable.get_data(**json_compatible_item_data)
    df1=pd.DataFrame(ex)
 
    url = "https://hooks.slack.com/services/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"
    pay = {
    "text": f"{df1}"
    }
    headers = {
    'Content-Type': 'application/json'
    }
    try:

        response = requests.post(url, headers=headers, data=json.dumps(pay),timeout=3)
        ex1=("User Notified over slack notification Channel")
        print(ex1)
        return {"message":"slack notified"}

    except Exception as err:

        slack_err = "Failed to Establish connection with Slack"
        Failure_channel.Failed_notification(slack_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while notifying Slack: " + str(err))

   
#slack_notify_user(fetch)
