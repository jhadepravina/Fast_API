import snow_get
import uvicorn
import requests
from fastapi import FastAPI

#app = FastAPI()
#requests.get('http://127.0.0.1:7000/api/v1/notifyuser/fetch')

#if __name__ == "__snow_get__":
 #    uvicorn.run(snow_get.app, port="7000", reload=True)

r = requests.get('http://127.0.0.1:7000/api/v1/notifyuser/fetch')
print(r.json())