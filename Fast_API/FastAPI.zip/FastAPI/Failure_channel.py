import pymsteams
import traceback2 as traceback
from fastapi import HTTPException

def Failed_notification(error):
    
    try:
        myTeamsMessage = pymsteams.connectorcard("https://hclo365.webhook.office.com/webhookb2/5707e544-582c-49d2-a139-c628b64cf97e@189de737-c93a-4f5a-8b68-6f4ca9941912/IncomingWebhook/8ea9aa57321443d4ad501567d1de8bf9/2e0b66fb-b623-4324-b233-b89682c52636")
        
        myTeamsMessage.text(error)
        #print(error)
        myTeamsMessage.send()
        # ex1="Failure Notification"
        # print(ex1)

    except Exception as err:

        traceback.print_exception(None, err, err.__traceback__)
        print("Error in API connection" + str(err))

    

   
 
#teams_notify_user(fetch1)